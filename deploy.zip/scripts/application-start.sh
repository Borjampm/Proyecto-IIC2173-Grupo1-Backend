#!/bin/bash
cd /home/ubuntu/Proyecto-IIC2173-Grupo1-Backend
docker compose --file docker-compose.production.yml up -d
